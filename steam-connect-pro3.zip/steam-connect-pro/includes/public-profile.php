<?php
if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/public-profile-tabs.php';

function scp_public_profile_template() {
    $steam_qv = sanitize_text_field((string) get_query_var('scp_steam_user'));
    $site_user_qv = absint(get_query_var('scp_site_user'));

    if (!$steam_qv && !$site_user_qv) {
        return;
    }

    $steam_id = '';
    $steam_data = [];
    $target_user_id = 0;

    if ($steam_qv) {
        $steam_id = $steam_qv;
        $steam_data = scp_get_steam_user_info($steam_id, true);
        if (!$steam_data) {
            wp_die('Steam user not found');
        }
        $target_user_id = function_exists('scp_find_user_by_steam_id') ? (int) scp_find_user_by_steam_id($steam_id) : 0;
        if ($target_user_id > 0) {
            $steam_data['avatar'] = scp_get_user_avatar_url($target_user_id, 160);
        }
    } else {
        $target_user_id = $site_user_qv;
        $wp_user = get_user_by('id', $target_user_id);
        if (!$wp_user) {
            wp_die('User not found');
        }

        $steam_id = sanitize_text_field((string) get_user_meta($target_user_id, 'steam_id', true));
        if ($steam_id) {
            $steam_data = scp_get_steam_user_info($steam_id, true);
        }

        $steam_name = is_array($steam_data) && !empty($steam_data['name']) ? $steam_data['name'] : '';
        $display_name = trim((string) $wp_user->display_name);

        $steam_data = is_array($steam_data) ? $steam_data : [];
        $steam_data['steamid'] = $steam_id;
        $steam_data['name'] = $display_name !== '' ? $display_name : ($steam_name ?: $wp_user->user_login);
        $steam_data['avatar'] = scp_get_user_avatar_url($target_user_id, 160);
        $steam_data['profile_url'] = !empty($steam_data['profile_url']) ? $steam_data['profile_url'] : '';
        $steam_data['level'] = !empty($steam_data['level']) ? (int) $steam_data['level'] : 0;
        $steam_data['online'] = !empty($steam_data['online']) ? (int) $steam_data['online'] : 0;
        $steam_data['current_game_name'] = !empty($steam_data['current_game_name']) ? $steam_data['current_game_name'] : '';
        $steam_data['current_game_image'] = !empty($steam_data['current_game_image']) ? $steam_data['current_game_image'] : '';
    }

    $friend_state = 'none';
    $friend_button_meta = [
        'class' => '',
        'disabled' => false,
        'label' => __('Add Friend', 'steam-connect-pro'),
    ];

    if (function_exists('scp_friends_get_button_meta')) {
        $friend_button_meta = scp_friends_get_button_meta('none');
    }

    if (is_user_logged_in() && $target_user_id && function_exists('scp_friends_get_relationship_state') && function_exists('scp_friends_get_button_meta')) {
        $friend_state = scp_friends_get_relationship_state(get_current_user_id(), (int) $target_user_id);
        $friend_button_meta = scp_friends_get_button_meta($friend_state);
    }

    $steam_level = intval($steam_data['level']);
    $level_class = scp_public_profile_get_level_class($steam_level);
    $current_game_name = isset($steam_data['current_game_name']) ? $steam_data['current_game_name'] : '';
    $current_game_image = isset($steam_data['current_game_image']) ? $steam_data['current_game_image'] : '';
    $has_steam_connected = !empty($steam_id) && !empty($steam_data['profile_url']);

    get_header();
    ?>

    <div class="scp-public-profile">
        <article class="scp-public-card-pro" <?php echo !empty($steam_data['steamid']) ? 'data-steamid="' . esc_attr($steam_data['steamid']) . '"' : ''; ?>>
            <div class="scp-current-game-corner">
                <div class="scp-current-game-box" data-has-game="<?php echo !empty($current_game_name) ? '1' : '0'; ?>">
                    <img src="<?php echo esc_url($current_game_image); ?>" alt="<?php echo esc_attr($current_game_name ? $current_game_name : 'Current Game'); ?>" class="scp-current-game-cover <?php echo empty($current_game_image) ? 'is-hidden' : ''; ?>">

                    <div class="scp-current-game-content">
                        <span class="scp-current-game-label">بازی در حال پلی توسط کاربر در استیم</span>
                        <strong class="scp-current-game-name"><?php echo esc_html($current_game_name ? $current_game_name : ' کاربر درحال پلی بازی نیست'); ?></strong>
                    </div>
                </div>
            </div>

            <div class="scp-public-card-head">
                <div class="scp-avatar-presence-wrap <?php echo $target_user_id ? '' : 'no-site-user'; ?>" <?php if ($target_user_id) : ?>data-scp-site-user-id="<?php echo esc_attr((int) $target_user_id); ?>"<?php endif; ?>>
                    <img src="<?php echo esc_url($steam_data['avatar']); ?>" class="scp-avatar-large" alt="<?php echo esc_attr($steam_data['name']); ?>">
                    <?php if ($target_user_id) : ?>
                        <span class="scp-site-presence-dot offline" data-tooltip="آفلاین در سایت"></span>
                    <?php endif; ?>
                </div>

                <div class="scp-public-user-info">
                    <h2><?php echo esc_html($steam_data['name']); ?><?php echo $target_user_id ? scp_get_verified_badge_html((int) $target_user_id, ['class' => 'scp-verified-badge-inline']) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></h2>

                    <?php if ($has_steam_connected) : ?>
                        <div class="scp-meta-row scp-meta-row-profile">
                            <span class="scp-level-badge <?php echo esc_attr($level_class); ?>" data-tooltip="<?php esc_attr_e('Steam Level', 'steam-connect-pro'); ?>">
                                <?php printf(esc_html__('Lv. %d', 'steam-connect-pro'), $steam_level); ?>
                            </span>

                            <span class="scp-online-status-profile <?php echo ($steam_data['online'] > 0 ? 'online' : 'offline'); ?>" data-tooltip="in steam">
                                <?php echo ($steam_data['online'] > 0 ? 'Online' : 'Offline'); ?>
                            </span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="scp-public-actions">
                <?php if (is_user_logged_in() && $target_user_id && get_current_user_id() !== (int) $target_user_id) : ?>
                    <button type="button" class="scp-chat-launch scp-chat-launch-profile" data-target-user="<?php echo esc_attr((int) $target_user_id); ?>" data-target-name="<?php echo esc_attr($steam_data['name']); ?>">
                        💬 چت با این کاربر
                    </button>

                    <?php if ($friend_state === 'friends') : ?>
                        <div class="scp-friend-split" data-target-user="<?php echo esc_attr((int) $target_user_id); ?>">
                            <button type="button" class="scp-friend-btn is-friends" data-friend-state="friends" disabled>Friends</button>
                            <button type="button" class="scp-friend-btn is-remove" data-friend-action="remove" data-target-user="<?php echo esc_attr((int) $target_user_id); ?>">Remove Friend</button>
                        </div>
                    <?php else : ?>
                        <button type="button"
                                class="scp-friend-btn <?php echo esc_attr($friend_button_meta['class']); ?>"
                                data-target-user="<?php echo esc_attr((int) $target_user_id); ?>"
                                data-friend-state="<?php echo esc_attr($friend_state); ?>"
                                <?php disabled(!empty($friend_button_meta['disabled'])); ?>>
                            <?php echo esc_html($friend_button_meta['label']); ?>
                        </button>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if ($has_steam_connected) : ?>
                    <a href="<?php echo esc_url($steam_data['profile_url']); ?>" target="_blank" rel="noopener noreferrer" class="scp-profile-link-steami">
                        View Steam Profile
                    </a>
                <?php endif; ?>
            </div>
        </article>

        <?php echo scp_public_profile_render_tabs($steam_id, $target_user_id); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
    </div>

    <?php
    get_footer();
    exit;
}
add_action('template_redirect', 'scp_public_profile_template');
