<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Remove plugin options
delete_option( 'scp_api_key' );
delete_option( 'scp_cache_profile_duration' );

// Note: We intentionally do not delete Steam-related user meta (steam_id, steam_name, steam_avatar) automatically.
// If you want to remove them, uncomment the following block (CAUTION):
/*
global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key IN ('steam_id', 'steam_name', 'steam_avatar')" );
*/
