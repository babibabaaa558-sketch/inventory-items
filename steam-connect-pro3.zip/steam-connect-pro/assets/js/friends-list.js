(function () {
    if (!window.scpAjax || !scpAjax.ajax_url) return;

    const root = document.getElementById('scp-friends-list-root');
    if (!root) return;

    const grid = document.getElementById('scp-friends-grid');
    if (!grid) return;

    const request = async (action, payload = {}) => {
        const body = new URLSearchParams({ action, nonce: scpAjax.nonce, ...payload });
        const res = await fetch(scpAjax.ajax_url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: body.toString(),
            credentials: 'same-origin',
        });
        const data = await res.json();
        if (!data.success) throw new Error((data.data && data.data.message) || 'request_failed');
        return data.data;
    };

    const getProfileUrl = (friend) => {
        const direct = String(friend.public_profile_url || '').trim();
        if (direct) return direct;
        const userId = Number(friend.id || 0);
        if (userId > 0) return `/?scp_site_user=${userId}`;
        return '#';
    };

    const applyPresenceState = () => {
        const map = window.scpSitePresenceState || {};
        root.querySelectorAll('[data-scp-site-user-id]').forEach((node) => {
            const uid = String(node.getAttribute('data-scp-site-user-id') || '');
            if (!uid || !(uid in map)) return;

            const dot = node.querySelector('.scp-site-presence-dot');
            if (!dot) return;

            const online = !!map[uid];
            dot.classList.remove('online', 'offline');
            dot.classList.add(online ? 'online' : 'offline');
            dot.setAttribute('data-tooltip', online ? 'آنلاین در سایت' : 'آفلاین در سایت');
        });
    };

    const esc = (v) => String(v || '').replace(/[&<>'"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
    const verifiedBadgeHtml = (isVerified) => {
        if (!isVerified) {
            return '';
        }

        return '<span class="scp-verified-badge scp-verified-badge-inline" role="img" aria-label="احراز هویت شده"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 2.5 9.3 4.7l-3.4-.1-.8 3.3-2.6 2.1 1.4 3-1.4 3 2.6 2.1.8 3.3 3.4-.1 2.7 2.2 2.7-2.2 3.4.1.8-3.3 2.6-2.1-1.4-3 1.4-3-2.6-2.1-.8-3.3-3.4.1L12 2.5Zm-1 14.4-3.2-3.2 1.4-1.4 1.8 1.8 4.2-4.2 1.4 1.4-5.6 5.6Z"></path></svg><span class="scp-verified-tooltip">احراز هویت شده</span></span>';
    };

    const render = (items) => {
        const safeItems = Array.isArray(items) ? items : [];
        if (!safeItems.length) {
            grid.innerHTML = '<div class="scp-friends-list-empty">هنوز دوستی ثبت نشده است.</div>';
            return;
        }

        grid.innerHTML = safeItems.map((friend) => {
            const user = friend.user || {};
            const id = Number(friend.id || 0);
            const name = String(user.name || 'User');
            const avatar = String(user.avatar || '');
            const since = String(friend.since_human || '');
            const profile = getProfileUrl(friend);
            const badge = verifiedBadgeHtml(!!user.is_verified);

            return `<div class="scp-friends-item" data-friend-id="${id}">
                <div class="scp-friends-item-main">
                    <a href="${esc(profile)}" class="scp-friend-user-link">
                        <span class="scp-avatar-presence-wrap" data-scp-site-user-id="${id}">
                            <img src="${esc(avatar)}" alt="${esc(name)}">
                            <span class="scp-site-presence-dot offline" data-tooltip="آفلاین در سایت"></span>
                        </span>
                    </a>
                    <div class="scp-friends-item-meta">
                        <a href="${esc(profile)}" class="scp-friend-user-link"><strong>${esc(name)}${badge}</strong></a>
                        <span>دوست از ${esc(since)} پیش</span>
                    </div>
                </div>
                <div class="scp-friends-item-actions">
                    <div class="scp-friend-split" data-target-user="${id}">
                        <button type="button" class="scp-friend-btn is-friends" data-friend-state="friends" disabled>Friends</button>
                        <button type="button" class="scp-friend-btn is-remove" data-friend-action="remove" data-target-user="${id}">Remove Friend</button>
                    </div>
                    <button type="button" class="scp-chat-launch scp-chat-launch-profile" data-target-user="${id}" data-target-name="${esc(name)}">💬 Chat</button>
                </div>
            </div>`;
        }).join('');

        applyPresenceState();
    };

    const refresh = async () => {
        try {
            const data = await request('scp_get_friends_list');
            render(data.items || []);
        } catch (e) {
            // silent
        }
    };

    window.addEventListener('scp:site-presence-updated', applyPresenceState);

    refresh();
    setInterval(refresh, 30000);
})();
