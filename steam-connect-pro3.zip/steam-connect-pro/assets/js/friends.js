(function () {
    if (!window.scpAjax || !scpAjax.ajax_url) {
        return;
    }

    const request = async (action, payload = {}) => {
        const body = new URLSearchParams({ action, nonce: scpAjax.nonce, ...payload });
        const res = await fetch(scpAjax.ajax_url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: body.toString(),
            credentials: 'same-origin',
        });

        const data = await res.json();
        if (!data.success) {
            throw new Error((data.data && data.data.message) || 'request_failed');
        }

        return data.data;
    };

    const renderSplitFriendsButton = (button) => {
        const targetUser = Number(button.dataset.targetUser || 0);
        const wrap = document.createElement('div');
        wrap.className = 'scp-friend-split';
        wrap.dataset.targetUser = String(targetUser);
        wrap.innerHTML = `<button type="button" class="scp-friend-btn is-friends" data-friend-state="friends" disabled>Friends</button>
            <button type="button" class="scp-friend-btn is-remove" data-friend-action="remove" data-target-user="${targetUser}">Remove Friend</button>`;
        button.replaceWith(wrap);
    };

    const applyFriendButtonState = (button, state) => {
        if (!button) return;

        if (state === 'friends') {
            renderSplitFriendsButton(button);
            return;
        }

        button.classList.remove('is-add', 'is-cancel', 'is-pending', 'is-friends', 'is-self', 'is-remove');

        const states = {
            none: { text: 'Add Friend', cls: 'is-add', disabled: false },
            outgoing: { text: 'Cancel Invite', cls: 'is-cancel', disabled: false },
            incoming: { text: 'Pending in Notifications', cls: 'is-pending', disabled: true },
            self: { text: 'Your Profile', cls: 'is-self', disabled: true },
        };

        const next = states[state] || states.none;
        button.textContent = next.text;
        button.classList.add(next.cls);
        button.disabled = !!next.disabled;
        button.dataset.friendState = state;
    };

    const steamWarningDefaults = {
        show: false,
        text: 'لطفا :آکانت استیم خود را متصل کنید تا بتوانید آکانت استیم خود را برای فروش قرار دهید.',
        link: 'https://gamebani.ir/sell-steam-account/',
    };

    const getSteamWarningFromRoot = () => {
        const root = document.getElementById('scp-notify-root');
        if (!root) return { ...steamWarningDefaults };

        const raw = String(root.dataset.showSteamWarning || '').trim();
        const show = raw === '1' || raw.toLowerCase() === 'true';
        const text = String(root.dataset.steamWarningText || '').trim() || steamWarningDefaults.text;
        const link = String(root.dataset.steamWarningLink || '').trim() || steamWarningDefaults.link;

        return { show, text, link };
    };

    const syncNotifyAttention = (count = 0, showSteamWarning = false) => {
        const toggle = document.getElementById('scp-notify-toggle');
        if (!toggle) return;

        const hasAttention = Number(count) > 0 || !!showSteamWarning;
        toggle.classList.toggle('is-attention', hasAttention);
    };

    const buildWarningHtml = (showSteamWarning, steamWarningText, steamWarningLink) => {
        if (!showSteamWarning) return '';

        const text = String(steamWarningText || '').trim() || steamWarningDefaults.text;
        const link = String(steamWarningLink || '').trim() || steamWarningDefaults.link;

        return `<div class="scp-notify-warning">
            <p class="scp-notify-warning-text">${text}</p>
            <a href="${link}" class="scp-notify-warning-btn" target="_blank" rel="noopener noreferrer">اتصال آکانت Steam</a>
        </div>`;
    };

    const renderNotifications = (items, showSteamWarning = false, steamWarningText = "", steamWarningLink = "") => {
        const list = document.getElementById('scp-notify-list');
        const count = document.getElementById('scp-notify-count');
        if (!list || !count) return;

        const safeItems = Array.isArray(items) ? items : [];
        const warningHtml = buildWarningHtml(showSteamWarning, steamWarningText, steamWarningLink);

        count.textContent = String(safeItems.length);
        count.classList.toggle('is-hidden', safeItems.length === 0);
        syncNotifyAttention(safeItems.length, showSteamWarning);

        if (!safeItems.length) {
            list.innerHTML = warningHtml + '<div class="scp-notify-empty">اعلان جدیدی وجود ندارد</div>';
            return;
        }

        list.innerHTML = warningHtml + safeItems.map((item) => {
            const user = item.from_user || {};
            const uid = Number(user.id || 0);
            const reqId = Number(item.request_id || 0);
            const name = String(user.name || 'User');
            const avatar = String(user.avatar || '');

            return `<div class="scp-notify-item" data-request-id="${reqId}">
                <span class="scp-avatar-presence-wrap" data-scp-site-user-id="${uid}">
                    <img src="${avatar}" alt="${name}">
                    <span class="scp-site-presence-dot offline" data-tooltip="آفلاین در سایت"></span>
                </span>
                <div class="scp-notify-user-meta">
                    <strong>${name}</strong>
                    <span>درخواست دوستی ارسال کرده است</span>
                </div>
                <div class="scp-notify-actions">
                    <button type="button" class="scp-notify-accept" data-request-id="${reqId}">قبول</button>
                    <button type="button" class="scp-notify-reject" data-request-id="${reqId}">رد</button>
                </div>
            </div>`;
        }).join('');
    };

    const refreshNotifications = async () => {
        const root = document.getElementById('scp-notify-root');
        if (!root || !scpAjax.current_user_id) return;

        try {
            const data = await request('scp_get_friend_requests');
            const rootWarning = getSteamWarningFromRoot();
            const hasShowFlag = Object.prototype.hasOwnProperty.call(data || {}, 'show_steam_connect_notice');
            const showWarning = hasShowFlag ? !!data.show_steam_connect_notice : rootWarning.show;
            const warningText = String((data && data.steam_connect_notice_text) || '').trim() || rootWarning.text || steamWarningDefaults.text;
            const warningLink = String((data && data.steam_connect_notice_link) || '').trim() || rootWarning.link || steamWarningDefaults.link;

            if (root) {
                root.dataset.showSteamWarning = showWarning ? '1' : '0';
                root.dataset.steamWarningText = warningText;
                root.dataset.steamWarningLink = warningLink;
            }

            renderNotifications(
                data.items || [],
                showWarning,
                warningText,
                warningLink
            );
        } catch (err) {
            // keep silent in UI
        }
    };

    document.addEventListener('click', async (event) => {
        const friendBtn = event.target.closest('.scp-friend-btn:not(.is-remove)');
        if (friendBtn) {
            if (!scpAjax.current_user_id) {
                return;
            }

            const targetUserId = Number(friendBtn.dataset.targetUser || 0);
            if (!targetUserId) return;

            const currentState = String(friendBtn.dataset.friendState || 'none');

            friendBtn.disabled = true;
            try {
                if (currentState === 'none') {
                    const data = await request('scp_send_friend_invite', { target_user_id: targetUserId });
                    applyFriendButtonState(friendBtn, data.state || 'outgoing');
                } else if (currentState === 'outgoing') {
                    const data = await request('scp_cancel_friend_invite', { target_user_id: targetUserId });
                    applyFriendButtonState(friendBtn, data.state || 'none');
                }
                await refreshNotifications();
            } catch (err) {
                friendBtn.disabled = false;
            }
            return;
        }

        const removeBtn = event.target.closest('.scp-friend-btn.is-remove, .scp-friend-btn[data-friend-action="remove"]');
        if (removeBtn) {
            if (!scpAjax.current_user_id) {
                return;
            }

            const targetUserId = Number(removeBtn.dataset.targetUser || removeBtn.closest('.scp-friend-split')?.dataset.targetUser || 0);
            if (!targetUserId) return;

            removeBtn.disabled = true;
            try {
                const data = await request('scp_remove_friend', { target_user_id: targetUserId });
                const split = removeBtn.closest('.scp-friend-split');
                const base = document.createElement('button');
                base.type = 'button';
                base.className = 'scp-friend-btn';
                base.dataset.targetUser = String(targetUserId);
                base.dataset.friendState = 'none';
                if (split) {
                    split.replaceWith(base);
                    applyFriendButtonState(base, data.state || 'none');
                }
                await refreshNotifications();
            } catch (err) {
                removeBtn.disabled = false;
            }
            return;
        }

        const notifyToggle = event.target.closest('#scp-notify-toggle');
        if (notifyToggle) {
            const panel = document.getElementById('scp-notify-panel');
            if (!panel) return;

            const expanded = notifyToggle.getAttribute('aria-expanded') === 'true';
            notifyToggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
            panel.hidden = expanded;

            if (!expanded) {
                await refreshNotifications();
            }
            return;
        }

        const decisionBtn = event.target.closest('.scp-notify-accept, .scp-notify-reject');
        if (decisionBtn) {
            const requestId = Number(decisionBtn.dataset.requestId || 0);
            if (!requestId) return;

            const decision = decisionBtn.classList.contains('scp-notify-accept') ? 'accept' : 'reject';
            decisionBtn.disabled = true;

            try {
                await request('scp_respond_friend_invite', {
                    request_id: requestId,
                    decision,
                });

                const row = decisionBtn.closest('.scp-notify-item');
                if (row) row.remove();
                await refreshNotifications();
            } catch (err) {
                decisionBtn.disabled = false;
            }
            return;
        }

        const notifyRoot = document.getElementById('scp-notify-root');
        if (notifyRoot && !event.target.closest('#scp-notify-root')) {
            const panel = document.getElementById('scp-notify-panel');
            const toggle = document.getElementById('scp-notify-toggle');
            if (panel && toggle && !panel.hidden) {
                panel.hidden = true;
                toggle.setAttribute('aria-expanded', 'false');
            }
        }
    });

    refreshNotifications();
    setInterval(refreshNotifications, 20000);
})();
